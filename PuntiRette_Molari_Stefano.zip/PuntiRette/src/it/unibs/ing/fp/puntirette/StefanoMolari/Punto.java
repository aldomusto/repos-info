package it.unibs.ing.fp.puntirette.StefanoMolari;

public class Punto {
	//� una classe di modello
	// due attributi double che rappresentano coordinata x e coordinata y, interni
	private double x;//this fa riferimento a questa x
	private double y;
	//il private � buona norma perch� evita di esporre direttamente l'accesso di questi attributi ad altre classi
	
	//costruttore
	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//metodi getter
	//per lavorare sui valori di x e di y in modo sicuro
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	//metodi setter
	public void setY(double y) {
		this.y = y;
	}

	public void setX(double x) {
		this.x = x;
	}
	
	
	//metodi vari
	public double distanza(Punto p2) {
		//espressione per il calcolo della distnza
		return Math.sqrt((Math.pow(x-p2.x, 2)+Math.pow(y-p2.y, 2)));
	}
	
	public boolean uguali(Punto p2) {
		return distanza(p2)==0;
		
	}
	
}
