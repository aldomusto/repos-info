package it.unibs.ing.fp.puntirette.StefanoMolari;
import it.unibs.fp.mylib.InputDati;
public class PuntiRetteMain {

	public static void main(String[] args) {
		// messaggio iniziale
		System.out.println("Programma \"Punti e Rette\" v0.1");
		//autore
		System.out.println("di Molari Stefano\n");

		// creazione di due punti con successivo inserimento valori da parte dell'utente
		Punto p1 = new Punto(InputDati.leggiDouble("inserisci x di p1: "),
				InputDati.leggiDouble("Inserisci y di p1: "));
		Punto p2 = new Punto(InputDati.leggiDouble("inserisci x di p2: "),
				InputDati.leggiDouble("Inserisci y di p2: "));

		// calcolo la distanza tra i due punti
		double distanza = p1.distanza(p2);

		// stampo sul terminale il resoconto dei dati inseriti e la distanza calcolata
		System.out.println(String.format("\nPunto1: (%.1f , %.1f)", p1.getX(), p1.getY()));
		System.out.println(String.format("Punto2: (%.1f , %.1f)", p2.getX(), p2.getY()));
		System.out.println(String.format("\nDistanza(p1,p2):%.2f ",distanza));
		
		// controllo se i due punti inseriti coincidono
		// scrivo a monitor l'equazione della retta tramite il metodo "toString()"
		boolean puntiUguali = p1.uguali(p2);
		System.out.println("\n[check]i due punti (p1 e p2) sono uguali? " + puntiUguali);
		if (puntiUguali == true) { // punti uguali
			System.out.println("\ni due punti sono uguali, impossibile calcolare la retta!");
		} else { // punti diversi
			Retta r = new Retta(p1, p2);
			System.out.println(r.toString());

			// creazione di un nuovo punto p3
			Punto p3 = new Punto(InputDati.leggiDouble("inserisci x di p3: "),
					InputDati.leggiDouble("\nInserisci x di p3: "));
			System.out.println(String.format("Punto3: (%.1f , %.1f)", p3.getX(), p3.getY()));
			// verifico che il punto p3 appartenga alla retta per p1 e p2
			boolean allineato = r.appartiene(p3);
			if (allineato)
				System.out.println("\np3 � allineato");
			else
				System.out.println("\np3 non � allineato");
		}//else punti diversi

	}//main

}
